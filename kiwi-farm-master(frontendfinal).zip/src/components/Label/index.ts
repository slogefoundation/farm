export { default } from './Label'
